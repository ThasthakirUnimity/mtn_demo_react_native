const Entry = [
  {
    image: require('@asset/images/recharge.png'),
    desc: 'Recharge Phone',
    points: 'Get up to N10000 \nCashback'
  },
  {
    image: require('@asset/images/paybills.png'),
    desc: 'Pay Credit Card Bill',
    points: 'Get up to N10000 \nCashback'
  },
  {
    image: require('@asset/images/recharge.png'),
    desc: 'Add money to \nmomo',
    points: 'Get up to N10000 \nCashback'
  },
  {
    image: require('@asset/images/paybills.png'),
    desc: 'Add money to \nmomo',
    points: 'Get up to N10000 \nCashback'
  },
]

export default Entry
