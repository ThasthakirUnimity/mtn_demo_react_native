import { CURRENCY } from '@src/theme/typography'

const Entry = [
  {
    image: require('@asset/images/ioh-logo.png'),
    voucherValue: 'Voucher Value '+ CURRENCY.SYMBOL +'100 Off by IOH',
    expires: 'Expires: 02 June 2021'
  },
  {
    image: require('@asset/images/ioh-logo.png'),
    voucherValue: 'Voucher Value '+ CURRENCY.SYMBOL +'100 Off by IOH',
    expires: 'Expires: 02 June 2021'
  },
]

export default Entry