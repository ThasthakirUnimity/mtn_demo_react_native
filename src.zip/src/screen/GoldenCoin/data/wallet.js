const Entry = [
  {
    image: require('@asset/images/momo.png'),
    desc: 'Add money to \nmomo',
    points: 'Earn Flat N1000 Cashback'
  },
  {
    image: require('@asset/images/momo.png'),
    desc: 'Add money to \nmomo',
    points: 'Earn Flat N1000 Cashback'
  },
  {
    image: require('@asset/images/momo.png'),
    desc: 'Add money to \nmomo',
    points: 'Earn Flat N1000 Cashback'
  },
  {
    image: require('@asset/images/momo.png'),
    desc: 'Add money to \nmomo',
    points: 'Earn Flat N1000 Cashback'
  },
]

export default Entry
