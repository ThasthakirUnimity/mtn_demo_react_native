import { CURRENCY } from '@src/theme/typography'

const Entry = [
  {
    price: CURRENCY.SYMBOL +'30'
  },
  {
    price: CURRENCY.SYMBOL +'30'
  },
  {
    price: CURRENCY.SYMBOL +'30'
  },
  {
    price: CURRENCY.SYMBOL +'30'
  },
  {
    price: CURRENCY.SYMBOL +'30'
  },
  {
    price: CURRENCY.SYMBOL +'30'
  },
]

export default Entry