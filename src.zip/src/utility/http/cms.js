import axios from 'axios'
import perf from '@react-native-firebase/perf'
import urlParse from 'url-parse'

import { CMS_API_TOKEN, CMS_API_URL } from '@src/config/env'
import { URLS } from '@src/config/url'
import { notifySessionExpired } from '@src/helper/user'
import { store } from '@src/store'

const instance = axios.create({
  baseURL: CMS_API_URL,
  withCredentials: false,
  xsrfCookieName: 'XSRF-TOKEN-API',
  xsrfHeaderName: 'X-XSRF-TOKEN-API'
})

instance.defaults.headers.common.Accept = 'application/json'

instance.interceptors.request.use(async (config) => {
  const state = store.getState()

  config.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
  config.headers.Pragma = 'no-cache'
  config.headers.Expires = 0

  config.headers.Authorization = CMS_API_TOKEN

  const parsed = urlParse(config.url, true)

  if (!config.params) {
    config.params = {}
  }
  config.params._format = 'json'

  if (state.setting.languageCode && state.setting.languageCode != state.setting.languageCodeDefault) {
    config.params.lang = state.setting.languageCode
  }

  config.url = parsed.href

  /* if (state.setting.languageCode && state.setting.languageCode != state.setting.languageCodeDefault) {
    if (config.url.indexOf('http://') === -1 && config.url.indexOf('https://') === -1) {
      config.url = '/' + state.setting.languageCode + (config.url.indexOf('/') === 0 ? '' : '/') + config.url
    }
  } */

  try {
    const httpMetric = perf().newHttpMetric(config.url, config.method)
    config.metadata = { httpMetric }

    // add any extra metric attributes, if required
    // httpMetric.putAttribute('userId', '12345678');

    await httpMetric.start()
  } catch (e) {}
  return config
})

instance.interceptors.response.use(
  async function (response) {
    try {
      // Request was successful, e.g. HTTP code 200

      const { httpMetric } = response.config.metadata

      // add any extra metric attributes if needed
      // httpMetric.putAttribute('userId', '12345678');

      httpMetric.setHttpResponseCode(response.status)
      httpMetric.setResponseContentType(response.headers['content-type'])
      await httpMetric.stop()
    } catch (e) {}
    return response
  },
  async function (error) {
    try {
      // Request failed, e.g. HTTP code 500
      if (error.response.status == '401') {
        if (error.response.config.url == URLS.USER_SESSION_INFORMATION) {
        } else {
          notifySessionExpired()
        }
      }

      const { httpMetric } = error.config.metadata
      console.log(httpMetric)

      // add any extra metric attributes if needed
      // httpMetric.putAttribute('userId', '12345678');

      httpMetric.setHttpResponseCode(error.response.status)
      httpMetric.setResponseContentType(error.response.headers['content-type'])
      await httpMetric.stop()
    } catch (e) {}
    return Promise.reject(error)
  }
)

export default instance
